### Integration Tests

This directory contains pytest tests which test that the cis-audit.py script works on it's target OS's. This is achieved by making changes to the underlying operating system and as such, do not run these integration tests on a host that you care about!
